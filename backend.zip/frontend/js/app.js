
// ESTATEHUB - FRONTEND JAVASCRIPT

const API_URL = "http://127.0.0.1:5000/api";

// Get HTML elements
const propertyContainer = document.getElementById("propertyContainer");
const citySearch = document.getElementById("citySearch");
const listingType = document.getElementById("listingType");
const searchBtn = document.getElementById("searchBtn");

// Format price in Indian Rupees
function formatPrice(price) {
    return new Intl.NumberFormat("en-IN", {
        style: "currency",
        currency: "INR",
        maximumFractionDigits: 0
    }).format(Number(price));
}

// Escape text before inserting database values into HTML
function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, character => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[character]);
}

// Display properties on homepage
function displayProperties(properties) {
    propertyContainer.innerHTML = "";

    if (!properties || properties.length === 0) {
        propertyContainer.innerHTML =
            "<p>No properties found. Try another search.</p>";
        return;
    }

    properties.forEach(property => {
        const card = document.createElement("div");
        card.className = "property-card";

        const imageURL = property.image_path
            ? `http://127.0.0.1:5000${property.image_path}`
            : "https://placehold.co/600x400?text=No+Image";

        card.innerHTML = `
            <img
                src="${escapeHTML(imageURL)}"
                alt="${escapeHTML(property.title)}"
            >

            <div class="property-info">
                <h3>${escapeHTML(property.title)}</h3>

                <p class="property-location">
                    📍 ${escapeHTML(property.address)},
                    ${escapeHTML(property.city_name)}
                </p>

                <p class="property-price">
                    ${formatPrice(property.price)}
                </p>

                <div class="property-details">
                    <span>🛏 ${escapeHTML(property.bedrooms)} Beds</span>
                    <span>🛁 ${escapeHTML(property.bathrooms)} Baths</span>
                    <span>📐 ${escapeHTML(property.area_sqft)} Sq.ft</span>
                </div>
            </div>
        `;

        card.style.cursor = "pointer";

        card.addEventListener("click", () => {
            window.location.href =
                `property-details.html?id=${property.property_id}`;
        });

        propertyContainer.appendChild(card);
    });
}

// Fetch properties from backend
async function loadProperties() {
    propertyContainer.innerHTML = "<p>Loading properties...</p>";

    try {
        const city = citySearch.value.trim();
        const type = listingType.value;

        const params = new URLSearchParams();

        if (city) {
            params.append("city", city);
        }

        if (type) {
            params.append("listing_type", type);
        }

        params.append("page", "1");
        params.append("limit", "20");

        const response = await fetch(
            `${API_URL}/properties?${params.toString()}`
        );

        if (!response.ok) {
            throw new Error("Unable to fetch properties.");
        }

        const data = await response.json();

        if (data.success) {
            displayProperties(data.properties);
        } else {
            propertyContainer.innerHTML =
                "<p>Unable to load properties.</p>";
        }

    } catch (error) {
        console.error("Property loading error:", error);

        propertyContainer.innerHTML = `
            <p>Unable to connect to EstateHub server.
            Please check whether your backend is running.</p>
        `;
    }
}

// Update navbar based on login status and role
function updateNavbar() {
    const loginBtn = document.getElementById("loginBtn");
    const signupBtn = document.getElementById("signupBtn");
    const userWelcome = document.getElementById("userWelcome");
    const logoutBtn = document.getElementById("logoutBtn");
    const mainNav = document.getElementById("mainNav");

    const token = localStorage.getItem("estatehubToken");
    const savedUser = localStorage.getItem("estatehubUser");

    // Default navigation for visitors
    mainNav.innerHTML = `
        <a href="index.html">Home</a>
        <a href="#properties">Properties</a>
        <a href="#about">About</a>
    `;

    if (token && savedUser) {
        try {
            const user = JSON.parse(savedUser);
            const role = (user.role || "").toLowerCase();

            loginBtn.style.display = "none";
            signupBtn.style.display = "none";

            userWelcome.textContent = `Welcome, ${user.name}!`;
            userWelcome.style.display = "inline";

            logoutBtn.style.display = "inline-block";

            // Owner navigation
            if (role === "owner") {
                mainNav.innerHTML += `
                    <a href="owner-dashboard.html">Dashboard</a>
                    <a href="my-properties.html">My Properties</a>
                    <a href="add-property.html">Add Property</a>
                    <a href="owner-enquiries.html">Enquiries</a>
                `;
            }

            // Buyer navigation
            else if (role === "buyer") {
                mainNav.innerHTML += `
                    <a href="buyer-dashboard.html">Dashboard</a>
                    <a href="my-enquiries.html">My Enquiries</a>
                `;
            }

            // Admin navigation
            else if (role === "admin") {
                mainNav.innerHTML += `
                    <a href="admin.html">Admin Dashboard</a>
                `;
            }

        } catch (error) {
            console.error("User information error:", error);

            localStorage.removeItem("estatehubToken");
            localStorage.removeItem("estatehubUser");

            showLoggedOutNavbar();
        }

    } else {
        showLoggedOutNavbar();
    }
}

// Show Login and Sign Up buttons
function showLoggedOutNavbar() {
    document.getElementById("loginBtn").style.display = "inline-block";
    document.getElementById("signupBtn").style.display = "inline-block";
    document.getElementById("userWelcome").style.display = "none";
    document.getElementById("logoutBtn").style.display = "none";
}

// Login button
document.getElementById("loginBtn").addEventListener("click", () => {
    window.location.href = "login.html";
});

// Signup button
document.getElementById("signupBtn").addEventListener("click", () => {
    window.location.href = "signup.html";
});

// Logout button
document.getElementById("logoutBtn").addEventListener("click", () => {
    localStorage.removeItem("estatehubToken");
    localStorage.removeItem("estatehubUser");

    updateNavbar();

    alert("You have logged out successfully!");
});

// Search button
searchBtn.addEventListener("click", loadProperties);

// Initialize homepage
document.addEventListener("DOMContentLoaded", () => {
    updateNavbar();
    loadProperties();
});
