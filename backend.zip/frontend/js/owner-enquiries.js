
const API_URL = "http://127.0.0.1:5000/api";

const enquiryContainer = document.getElementById("enquiryContainer");

async function loadOwnerEnquiries() {
    const token = localStorage.getItem("estatehubToken");
    const userData = localStorage.getItem("estatehubUser");

    if (!token || !userData) {
        enquiryContainer.innerHTML =
            "<p>Please log in as an owner to view received enquiries.</p>";
        return;
    }

    const user = JSON.parse(userData);

    if (user.role !== "owner") {
        enquiryContainer.innerHTML =
            "<p>This page is available only to property owners.</p>";
        return;
    }

    try {
        const response = await fetch(`${API_URL}/enquiries/owner`, {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${token}`
            }
        });

        const data = await response.json();

        if (!response.ok || !data.success) {
            enquiryContainer.innerHTML =
                `<p>${data.message || "Unable to load enquiries."}</p>`;
            return;
        }

        if (data.enquiries.length === 0) {
            enquiryContainer.innerHTML =
                "<p>You have not received any enquiries yet.</p>";
            return;
        }

        enquiryContainer.innerHTML = data.enquiries.map(enquiry => `
            <div class="enquiry-card">
                <h3>${escapeHTML(enquiry.property_title)}</h3>

                <p><strong>Buyer Name:</strong>
                    ${escapeHTML(enquiry.buyer_name)}
                </p>

                <p><strong>Message:</strong></p>
                <p>${escapeHTML(enquiry.message)}</p>

                <p><strong>Status:</strong>
                    <span class="status">
                        ${escapeHTML(enquiry.status)}
                    </span>
                </p>

                <p><strong>Received On:</strong>
                    ${new Date(enquiry.created_at).toLocaleString("en-IN")}
                </p>
            </div>
        `).join("");

    } catch (error) {
        console.error("Error loading enquiries:", error);
        enquiryContainer.innerHTML =
            "<p>Unable to connect to the server. Please try again.</p>";
    }
}

function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, character => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;"
    })[character]);
}

loadOwnerEnquiries();
