
// ESTATEHUB - ADMIN DASHBOARD JAVASCRIPT

const API_URL = "http://127.0.0.1:5000/api";

const propertyList = document.getElementById("propertyList");
const message = document.getElementById("message");
const adminWelcome = document.getElementById("adminWelcome");
const logoutBtn = document.getElementById("logoutBtn");

// Check admin login
const token = localStorage.getItem("estatehubToken");
const userData = localStorage.getItem("estatehubUser");

let adminUser = null;

try {
    adminUser = JSON.parse(userData || "null");
} catch (error) {
    adminUser = null;
}

if (!token || !adminUser || adminUser.role !== "admin") {
    alert("Please log in using an admin account.");
    window.location.href = "login.html";
} else {
    adminWelcome.textContent = `Welcome, ${adminUser.name}!`;
    loadPendingProperties();
}

// Logout
logoutBtn.addEventListener("click", () => {
    localStorage.removeItem("estatehubToken");
    localStorage.removeItem("estatehubUser");

    window.location.href = "index.html";
});

// Load pending properties
async function loadPendingProperties() {

    message.textContent = "Loading properties...";

    try {
        const response = await fetch(
            `${API_URL}/admin/pending-properties`,
            {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            }
        );

        const data = await response.json();

        if (!response.ok || !data.success) {
            throw new Error(data.message || "Unable to load properties.");
        }

        propertyList.innerHTML = "";

        if (!data.properties || data.properties.length === 0) {
            message.textContent = "No pending properties available.";
            return;
        }

        message.textContent =
            `${data.count} pending properties found.`;

        data.properties.forEach(property => {

            const card = document.createElement("div");
            card.className = "admin-property";

            card.innerHTML = `
                <h2>${escapeHTML(property.title)}</h2>

                <p><strong>Property ID:</strong>
                    ${escapeHTML(property.property_id)}
                </p>

                <p><strong>Owner:</strong>
                    ${escapeHTML(property.owner_name)}
                </p>

                <p><strong>City:</strong>
                    ${escapeHTML(property.city_name)}
                </p>

                <p><strong>Type:</strong>
                    ${escapeHTML(property.type_name)}
                </p>

                <p><strong>Address:</strong>
                    ${escapeHTML(property.address)}
                </p>

                <p><strong>Price:</strong>
                    ₹${Number(property.price).toLocaleString("en-IN")}
                </p>

                <p><strong>Bedrooms:</strong>
                    ${escapeHTML(property.bedrooms)}
                </p>

                <p><strong>Bathrooms:</strong>
                    ${escapeHTML(property.bathrooms)}
                </p>

                <p><strong>Area:</strong>
                    ${escapeHTML(property.area_sqft)} sq.ft.
                </p>

                <p><strong>Status:</strong>
                    ${escapeHTML(property.status)}
                </p>

                <div class="admin-actions">

                    <button
                        class="approve-btn"
                        data-id="${escapeHTML(property.property_id)}">
                        Approve
                    </button>

                    <button
                        class="reject-btn"
                        data-id="${escapeHTML(property.property_id)}">
                        Reject
                    </button>

                </div>
            `;

            propertyList.appendChild(card);
        });

    } catch (error) {
        message.textContent = error.message;
        console.error("Admin loading error:", error);
    }
}

// Escape HTML
function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, character => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[character]);
}

// Approve or reject property
async function updateStatus(propertyId, status) {

    try {
        const response = await fetch(
            `${API_URL}/admin/properties/${propertyId}/status`,
            {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                },
                body: JSON.stringify({ status })
            }
        );

        const data = await response.json();

        if (!response.ok || !data.success) {
            throw new Error(data.message || "Unable to update property.");
        }

        alert(data.message);

        loadPendingProperties();

    } catch (error) {
        alert(error.message);
    }
}

// Handle Approve and Reject buttons
propertyList.addEventListener("click", function(event) {

    const button = event.target.closest("button");

    if (!button) return;

    const propertyId = button.dataset.id;

    if (button.classList.contains("approve-btn")) {

        if (confirm("Are you sure you want to approve this property?")) {
            updateStatus(propertyId, "approved");
        }

    }

    if (button.classList.contains("reject-btn")) {

        if (confirm("Are you sure you want to reject this property?")) {
            updateStatus(propertyId, "rejected");
        }

    }

});
