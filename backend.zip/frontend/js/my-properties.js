
const API_URL = "http://127.0.0.1:5000/api";

const propertyContainer = document.getElementById("propertyContainer");

async function loadMyProperties() {
    const token = localStorage.getItem("estatehubToken");
    const userData = localStorage.getItem("estatehubUser");

    if (!token || !userData) {
        propertyContainer.innerHTML = "<p>Please log in first.</p>";
        return;
    }

    let user;

    try {
        user = JSON.parse(userData);
    } catch (error) {
        propertyContainer.innerHTML = "<p>Invalid login information. Please log in again.</p>";
        return;
    }

    if (user.role !== "owner") {
        propertyContainer.innerHTML = "<p>Only property owners can access this page.</p>";
        return;
    }

    try {
        const response = await fetch(`${API_URL}/properties/my-properties`, {
            headers: {
                "Authorization": `Bearer ${token}`
            }
        });

        const data = await response.json();

        if (!response.ok || !data.success) {
            propertyContainer.innerHTML =
                `<p>${escapeHTML(data.message || "Unable to load properties.")}</p>`;
            return;
        }

        if (!data.properties || data.properties.length === 0) {
            propertyContainer.innerHTML = "<p>You have not added any properties yet.</p>";
            return;
        }

        propertyContainer.innerHTML = data.properties.map(property => `
            <div class="property-card">
                <h3>${escapeHTML(property.title)}</h3>

                <p><strong>Property ID:</strong> ${property.property_id}</p>

                <p><strong>Address:</strong> ${escapeHTML(property.address)}</p>

                <p><strong>Price:</strong> ₹${Number(property.price).toLocaleString("en-IN")}</p>

                <p><strong>Listing Type:</strong> ${escapeHTML(property.listing_type)}</p>

                <p><strong>Bedrooms:</strong> ${property.bedrooms}</p>

                <p><strong>Bathrooms:</strong> ${property.bathrooms}</p>

                <p><strong>Area:</strong> ${property.area_sqft} sq. ft.</p>

                <p><strong>Status:</strong>
                    <span class="status">${escapeHTML(property.status)}</span>
                </p>

                <div class="property-actions">
                    <button class="edit-btn"
                        onclick="editProperty(${property.property_id})">
                        Edit
                    </button>

                    <button class="delete-btn"
                        onclick="deleteProperty(${property.property_id})">
                        Delete
                    </button>
                </div>
            </div>
        `).join("");

    } catch (error) {
        console.error(error);
        propertyContainer.innerHTML =
            "<p>Unable to connect to the server. Please try again.</p>";
    }
}

function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, character => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;"
    })[character]);
}

function editProperty(propertyId) {
    window.location.href = `edit-property.html?id=${propertyId}`;
}

async function deleteProperty(propertyId) {
    const confirmDelete = confirm(
        "Are you sure you want to delete this property?"
    );

    if (!confirmDelete) return;

    const token = localStorage.getItem("estatehubToken");

    try {
        const response = await fetch(`${API_URL}/properties/${propertyId}`, {
            method: "DELETE",
            headers: {
                "Authorization": `Bearer ${token}`
            }
        });

        const data = await response.json();

        if (!response.ok || !data.success) {
            alert(data.message || "Unable to delete property.");
            return;
        }

        alert("Property deleted successfully!");
        loadMyProperties();

    } catch (error) {
        console.error(error);
        alert("Unable to connect to the server.");
    }
}

loadMyProperties();
