
const API_URL = "http://127.0.0.1:5000/api";

const signupForm = document.getElementById("signupForm");
const signupMessage = document.getElementById("signupMessage");

signupForm.addEventListener("submit", async function(event) {
    event.preventDefault();

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const phone = document.getElementById("phone").value.trim();
    const role = document.getElementById("role").value;

    signupMessage.textContent = "Creating account...";
    signupMessage.style.color = "blue";

    try {
        const response = await fetch(`${API_URL}/auth/register`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                name,
                email,
                password,
                phone,
                role
            })
        });

        const data = await response.json();

        if (!response.ok || !data.success) {
            signupMessage.textContent =
                data.message || "Registration failed.";
            signupMessage.style.color = "red";
            return;
        }

        signupMessage.textContent =
            "Account created successfully! Redirecting to login...";
        signupMessage.style.color = "green";

        signupForm.reset();

        setTimeout(() => {
            window.location.href = "login.html";
        }, 1500);

    } catch (error) {
        console.error("Signup error:", error);
        signupMessage.textContent =
            "Unable to connect to the server.";
        signupMessage.style.color = "red";
    }
});
