
const user = JSON.parse(
    localStorage.getItem("estatehubUser") || "null"
);

const token = localStorage.getItem("estatehubToken");

// Check owner login
if (!user || !token || user.role !== "owner") {
    window.location.href = "login.html";
} else {
    document.getElementById("ownerWelcome").textContent =
        `Welcome, ${user.name}!`;
}

// Logout
document.getElementById("logoutBtn").addEventListener("click", () => {
    localStorage.removeItem("estatehubToken");
    localStorage.removeItem("estatehubUser");

    window.location.href = "index.html";
});
