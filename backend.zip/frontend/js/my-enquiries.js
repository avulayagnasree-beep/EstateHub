
// ESTATEHUB - BUYER ENQUIRY DASHBOARD

const API_URL = "http://127.0.0.1:5000/api";

const enquiryContainer = document.getElementById("enquiryContainer");

// Escape database values before displaying them
function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, character => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[character]);
}

// Format enquiry date
function formatDate(date) {
    if (!date) return "Date unavailable";

    const parsedDate = new Date(date);

    if (isNaN(parsedDate.getTime())) {
        return "Date unavailable";
    }

    return parsedDate.toLocaleString("en-IN");
}

// Display enquiries
function displayEnquiries(enquiries) {
    enquiryContainer.innerHTML = "";

    if (!enquiries || enquiries.length === 0) {
        enquiryContainer.innerHTML =
            "<p>You haven't sent any enquiries yet.</p>";
        return;
    }

    enquiries.forEach(enquiry => {
        const card = document.createElement("div");
        card.className = "enquiry-card";

        card.innerHTML = `
            <h3>${escapeHTML(enquiry.property_title)}</h3>

            <p>
                📍 ${escapeHTML(enquiry.address)},
                ${escapeHTML(enquiry.city_name)}
            </p>

            <h4>Your Message</h4>

            <p>${escapeHTML(enquiry.message)}</p>

            <p>
                <strong>Status:</strong>
                <span class="status">
                    ${escapeHTML(enquiry.status)}
                </span>
            </p>

            <p>
                <strong>Sent On:</strong>
                ${escapeHTML(formatDate(enquiry.created_at))}
            </p>
        `;

        enquiryContainer.appendChild(card);
    });
}

// Load buyer enquiries
async function loadMyEnquiries() {
    const token = localStorage.getItem("estatehubToken");
    const savedUser = localStorage.getItem("estatehubUser");

    if (!token || !savedUser) {
        enquiryContainer.innerHTML = `
            <p>Please login to view your enquiries.</p>
            <a href="login.html">Login Here</a>
        `;
        return;
    }

    try {
        const user = JSON.parse(savedUser);

        if (user.role !== "buyer") {
            enquiryContainer.innerHTML =
                "<p>This dashboard is only available to buyers.</p>";
            return;
        }

        enquiryContainer.innerHTML = "<p>Loading enquiries...</p>";

        const response = await fetch(
            `${API_URL}/enquiries/my-enquiries`,
            {
                method: "GET",
                headers: {
                    "Authorization": `Bearer ${token}`
                }
            }
        );

        const data = await response.json();

        if (!response.ok || !data.success) {
            enquiryContainer.innerHTML =
                `<p>${escapeHTML(data.message || "Unable to load enquiries.")}</p>`;
            return;
        }

        displayEnquiries(data.enquiries);

    } catch (error) {
        console.error("Enquiry loading error:", error);

        enquiryContainer.innerHTML =
            "<p>Unable to connect to EstateHub server.</p>";
    }
}

// Start dashboard
loadMyEnquiries();
