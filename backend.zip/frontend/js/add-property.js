
const API_URL = "http://127.0.0.1:5000/api";

const propertyForm = document.getElementById("propertyForm");
const formMessage = document.getElementById("formMessage");

propertyForm.addEventListener("submit", async function (event) {
    event.preventDefault();

    const token = localStorage.getItem("estatehubToken");
    const userData = localStorage.getItem("estatehubUser");

    if (!token || !userData) {
        formMessage.textContent = "Please log in first.";
        formMessage.style.color = "red";
        return;
    }

    let user;

    try {
        user = JSON.parse(userData);
    } catch (error) {
        formMessage.textContent = "Login information is invalid. Please log in again.";
        formMessage.style.color = "red";
        return;
    }

    if (user.role !== "owner") {
        formMessage.textContent = "Only property owners can add properties.";
        formMessage.style.color = "red";
        return;
    }

    // Get selected images
    const imageInput = document.getElementById("images");
    const selectedImages = imageInput.files;

    if (selectedImages.length > 5) {
        formMessage.textContent = "You can upload a maximum of 5 images.";
        formMessage.style.color = "red";
        return;
    }

    const propertyData = {
        title: document.getElementById("title").value.trim(),
        description: document.getElementById("description").value.trim(),
        city_id: Number(document.getElementById("city_id").value),
        type_id: Number(document.getElementById("type_id").value),
        address: document.getElementById("address").value.trim(),
        price: Number(document.getElementById("price").value),
        listing_type: document.getElementById("listing_type").value,
        bedrooms: Number(document.getElementById("bedrooms").value),
        bathrooms: Number(document.getElementById("bathrooms").value),
        area_sqft: Number(document.getElementById("area_sqft").value)
    };

    formMessage.textContent = "Submitting property...";
    formMessage.style.color = "#24734b";

    try {
        // First save the property
        const response = await fetch(`${API_URL}/properties`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`
            },
            body: JSON.stringify(propertyData)
        });

        const data = await response.json();

        if (!response.ok || !data.success) {
            throw new Error(data.message || "Property submission failed.");
        }

        const propertyId = data.propertyId;

        // Upload images if selected
        if (selectedImages.length > 0) {
            formMessage.textContent = "Property saved. Uploading images...";

            const formData = new FormData();

            for (let i = 0; i < selectedImages.length; i++) {
                formData.append("images", selectedImages[i]);
            }

            const imageResponse = await fetch(
                `${API_URL}/properties/${propertyId}/images`,
                {
                    method: "POST",
                    headers: {
                        "Authorization": `Bearer ${token}`
                    },
                    body: formData
                }
            );

            const imageData = await imageResponse.json();

            if (!imageResponse.ok || !imageData.success) {
                throw new Error(
                    imageData.message ||
                    "Property saved, but image upload failed. Please contact your project administrator."
                );
            }
        }

        formMessage.textContent =
            "Success! Property submitted for admin approval. Property ID: " +
            propertyId +
            (selectedImages.length > 0
                ? ". Images uploaded successfully!"
                : ". No images selected.");

        formMessage.style.color = "green";

        propertyForm.reset();

    } catch (error) {
        console.error("Property submission error:", error);

        formMessage.textContent =
            error.message || "Unable to connect to the server.";

        formMessage.style.color = "red";
    }
});
