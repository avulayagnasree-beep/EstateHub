
const API_URL = "http://127.0.0.1:5000/api";

const editPropertyForm = document.getElementById("editPropertyForm");
const formMessage = document.getElementById("formMessage");

// Get property ID from URL
const urlParams = new URLSearchParams(window.location.search);
const propertyId = urlParams.get("id");

// Load existing property details
async function loadProperty() {
    const token = localStorage.getItem("estatehubToken");
    const userData = localStorage.getItem("estatehubUser");

    if (!token || !userData) {
        formMessage.textContent = "Please log in first.";
        return;
    }

    let user;

    try {
        user = JSON.parse(userData);
    } catch (error) {
        formMessage.textContent = "Invalid login information.";
        return;
    }

    if (user.role !== "owner") {
        formMessage.textContent = "Only property owners can edit properties.";
        return;
    }

    if (!propertyId || !/^[1-9]\d*$/.test(propertyId)) {
        formMessage.textContent = "Invalid property ID.";
        return;
    }

    try {
        const response = await fetch(`${API_URL}/properties/my-properties`, {
            headers: {
                "Authorization": `Bearer ${token}`
            }
        });

        const data = await response.json();

        if (!response.ok || !data.success) {
            throw new Error(data.message || "Unable to load properties.");
        }

        const property = data.properties.find(
            item => Number(item.property_id) === Number(propertyId)
        );

        if (!property) {
            formMessage.textContent = "Property not found.";
            return;
        }

        // Fill form with existing property details
        document.getElementById("title").value = property.title;
        document.getElementById("description").value = property.description;
        document.getElementById("city_id").value = property.city_id;
        document.getElementById("type_id").value = property.type_id;
        document.getElementById("address").value = property.address;
        document.getElementById("price").value = property.price;
        document.getElementById("listing_type").value = property.listing_type;
        document.getElementById("bedrooms").value = property.bedrooms ?? 0;
        document.getElementById("bathrooms").value = property.bathrooms ?? 0;
        document.getElementById("area_sqft").value = property.area_sqft ?? 0;

        formMessage.textContent = "Property details loaded successfully.";
        formMessage.style.color = "green";

    } catch (error) {
        console.error(error);
        formMessage.textContent = error.message || "Unable to connect to server.";
        formMessage.style.color = "red";
    }
}

// Save updated property details
editPropertyForm.addEventListener("submit", async function(event) {
    event.preventDefault();

    const token = localStorage.getItem("estatehubToken");

    const propertyData = {
        title: document.getElementById("title").value.trim(),
        description: document.getElementById("description").value.trim(),
        city_id: Number(document.getElementById("city_id").value),
        type_id: Number(document.getElementById("type_id").value),
        address: document.getElementById("address").value.trim(),
        price: Number(document.getElementById("price").value),
        listing_type: document.getElementById("listing_type").value,
        bedrooms: Number(document.getElementById("bedrooms").value),
        bathrooms: Number(document.getElementById("bathrooms").value),
        area_sqft: Number(document.getElementById("area_sqft").value)
    };

    formMessage.textContent = "Saving changes...";
    formMessage.style.color = "#24734b";

    try {
        const response = await fetch(`${API_URL}/properties/${propertyId}`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`
            },
            body: JSON.stringify(propertyData)
        });

        const data = await response.json();

        if (!response.ok || !data.success) {
            throw new Error(data.message || "Unable to update property.");
        }

        formMessage.textContent =
            "Property updated successfully! It is now pending admin approval.";

        formMessage.style.color = "green";

    } catch (error) {
        console.error(error);
        formMessage.textContent = error.message || "Unable to connect to server.";
        formMessage.style.color = "red";
    }
});

// Start loading
loadProperty();
