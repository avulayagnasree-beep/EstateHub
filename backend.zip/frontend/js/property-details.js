
// ESTATEHUB - PROPERTY DETAILS AND ENQUIRY

const API_URL = "http://127.0.0.1:5000/api";

const propertyDetails = document.getElementById("propertyDetails");

// Get property ID from URL
const params = new URLSearchParams(window.location.search);
const propertyId = params.get("id");

// Format price in Indian currency
function formatPrice(price) {
    return new Intl.NumberFormat("en-IN", {
        style: "currency",
        currency: "INR",
        maximumFractionDigits: 0
    }).format(Number(price));
}

// Protect displayed text
function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, character => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[character]);
}

// Load property details
async function loadPropertyDetails() {

    if (!propertyId || !/^[1-9]\d*$/.test(propertyId)) {
        propertyDetails.innerHTML = "<h2>Invalid property ID</h2>";
        return;
    }

    try {
        const response = await fetch(
            `${API_URL}/properties/${propertyId}`
        );

        const data = await response.json();

        if (!response.ok || !data.success) {
            propertyDetails.innerHTML =
                "<h2>Property not found</h2>";
            return;
        }

        const property = data.property;

        const imageURL = property.image_path
            ? `http://127.0.0.1:5000${property.image_path}`
            : "https://placehold.co/900x500?text=No+Image";

        propertyDetails.innerHTML = `
            <img
                src="${escapeHTML(imageURL)}"
                alt="${escapeHTML(property.title)}"
                class="details-image"
            >

            <div class="details-content">

                <h1>${escapeHTML(property.title)}</h1>

                <p>
                    📍 ${escapeHTML(property.address)},
                    ${escapeHTML(property.city_name)}
                </p>

                <div class="details-price">
                    ${formatPrice(property.price)}
                    ${property.listing_type === "rent" ? "/ month" : ""}
                </div>

                <div class="details-features">
                    <span>🛏 ${escapeHTML(property.bedrooms)} Bedrooms</span>
                    <span>🛁 ${escapeHTML(property.bathrooms)} Bathrooms</span>
                    <span>📐 ${escapeHTML(property.area_sqft)} Sq.ft</span>
                </div>

                <h2>Property Information</h2>

                <p>
                    <strong>Property Type:</strong>
                    ${escapeHTML(property.type_name)}
                </p>

                <p>
                    <strong>Listing:</strong>
                    ${escapeHTML(property.listing_type)}
                </p>

                <p>
                    <strong>Owner:</strong>
                    ${escapeHTML(property.owner_name)}
                </p>

                <h2>Description</h2>

                <p>${escapeHTML(property.description)}</p>

                <hr>

                <div class="enquiry-section">
                    <h2>Interested in this Property?</h2>

                    <p>Send an enquiry to the property owner.</p>

                    <form id="enquiryForm">
                        <textarea
                            id="enquiryMessage"
                            rows="5"
                            maxlength="1000"
                            placeholder="Write your enquiry message here..."
                            required
                            style="width:100%; padding:12px; box-sizing:border-box; border:1px solid #ccc; border-radius:8px;"
                        ></textarea>

                        <button type="submit" class="contact-owner">
                            Send Enquiry
                        </button>

                        <p id="enquiryStatus"></p>
                    </form>
                </div>

            </div>
        `;

        setupEnquiryForm();

    } catch (error) {
        console.error("Error loading property:", error);

        propertyDetails.innerHTML =
            "<h2>Unable to load property details. Please try again.</h2>";
    }
}

// Send enquiry to backend
function setupEnquiryForm() {

    const enquiryForm = document.getElementById("enquiryForm");
    const enquiryStatus = document.getElementById("enquiryStatus");

    enquiryForm.addEventListener("submit", async function(event) {

        event.preventDefault();

        const token = localStorage.getItem("estatehubToken");
        const savedUser = localStorage.getItem("estatehubUser");

        if (!token || !savedUser) {
            enquiryStatus.textContent =
                "Please login before sending an enquiry.";
            enquiryStatus.style.color = "red";
            return;
        }

        let user;

        try {
            user = JSON.parse(savedUser);
        } catch (error) {
            enquiryStatus.textContent =
                "Please login again to continue.";
            enquiryStatus.style.color = "red";
            return;
        }

        if (user.role !== "buyer") {
            enquiryStatus.textContent =
                "Only buyer accounts can send property enquiries.";
            enquiryStatus.style.color = "red";
            return;
        }

        const message = document
            .getElementById("enquiryMessage")
            .value.trim();

        if (!message) {
            enquiryStatus.textContent =
                "Please enter an enquiry message.";
            enquiryStatus.style.color = "red";
            return;
        }

        enquiryStatus.textContent = "Sending enquiry...";
        enquiryStatus.style.color = "blue";

        try {
            const response = await fetch(`${API_URL}/enquiries`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                },
                body: JSON.stringify({
                    property_id: Number(propertyId),
                    message: message
                })
            });

            const result = await response.json();

            if (!response.ok || !result.success) {
                enquiryStatus.textContent =
                    result.message || "Unable to send enquiry.";
                enquiryStatus.style.color = "red";
                return;
            }

            enquiryStatus.textContent =
                "Enquiry sent successfully!";
            enquiryStatus.style.color = "green";

            enquiryForm.reset();

        } catch (error) {
            console.error("Enquiry error:", error);

            enquiryStatus.textContent =
                "Unable to connect to the server.";
            enquiryStatus.style.color = "red";
        }
    });
}

// Start
loadPropertyDetails();
