
const API_URL = "http://127.0.0.1:5000/api";

const user = JSON.parse(
    localStorage.getItem("estatehubUser") || "null"
);

const token = localStorage.getItem("estatehubToken");

// Check buyer login
if (!user || !token || user.role !== "buyer") {
    window.location.href = "login.html";
}

// Display buyer name
document.getElementById("buyerWelcome").textContent =
    user ? `Welcome, ${user.name}!` : "";

// Logout
document.getElementById("logoutBtn").addEventListener("click", () => {
    localStorage.removeItem("estatehubToken");
    localStorage.removeItem("estatehubUser");

    window.location.href = "index.html";
});

// Format price
function formatPrice(price) {
    return new Intl.NumberFormat("en-IN", {
        style: "currency",
        currency: "INR",
        maximumFractionDigits: 0
    }).format(Number(price));
}

// Escape database values
function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, character => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[character]);
}

// Display properties
function displayProperties(properties) {
    const container = document.getElementById("propertyContainer");

    container.innerHTML = "";

    if (!properties || properties.length === 0) {
        container.innerHTML = "<p>No properties found.</p>";
        return;
    }

    properties.forEach(property => {
        const card = document.createElement("div");
        card.className = "property-card";

        const imageURL = property.image_path
            ? `http://127.0.0.1:5000${property.image_path}`
            : "https://placehold.co/600x400?text=No+Image";

        card.innerHTML = `
            <img src="${escapeHTML(imageURL)}"
                 alt="${escapeHTML(property.title)}">

            <div class="property-info">
                <h3>${escapeHTML(property.title)}</h3>

                <p>
                    📍 ${escapeHTML(property.address)},
                    ${escapeHTML(property.city_name)}
                </p>

                <p class="property-price">
                    ${formatPrice(property.price)}
                </p>

                <div class="property-details">
                    <span>🛏 ${escapeHTML(property.bedrooms)} Beds</span>
                    <span>🛁 ${escapeHTML(property.bathrooms)} Baths</span>
                    <span>📐 ${escapeHTML(property.area_sqft)} Sq.ft</span>
                </div>
            </div>
        `;

        card.style.cursor = "pointer";

        card.addEventListener("click", () => {
            window.location.href =
                `property-details.html?id=${property.property_id}`;
        });

        container.appendChild(card);
    });
}

// Load properties
async function loadProperties() {
    const container = document.getElementById("propertyContainer");

    container.innerHTML = "<p>Loading properties...</p>";

    const city = document.getElementById("citySearch").value.trim();
    const type = document.getElementById("listingType").value;

    const params = new URLSearchParams();

    if (city) params.append("city", city);
    if (type) params.append("listing_type", type);

    params.append("page", "1");
    params.append("limit", "20");

    try {
        const response = await fetch(
            `${API_URL}/properties?${params.toString()}`
        );

        if (!response.ok) {
            throw new Error("Failed to load properties");
        }

        const data = await response.json();

        if (data.success) {
            displayProperties(data.properties);
        } else {
            container.innerHTML = "<p>Unable to load properties.</p>";
        }

    } catch (error) {
        console.error(error);
        container.innerHTML =
            "<p>Unable to connect to EstateHub server.</p>";
    }
}

// Search
document.getElementById("searchBtn")
    .addEventListener("click", loadProperties);

// Initial loading
loadProperties();
