
const API_URL = "http://127.0.0.1:5000/api";

// Get login form elements
const loginForm = document.getElementById("loginForm");
const loginMessage = document.getElementById("loginMessage");

// Handle login
loginForm.addEventListener("submit", async function(event) {

    event.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;

    loginMessage.textContent = "Logging in...";
    loginMessage.style.color = "blue";

    try {

        const response = await fetch(`${API_URL}/auth/login`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                email: email,
                password: password
            })
        });

        const data = await response.json();

        if (!response.ok || !data.success) {
            loginMessage.textContent =
                data.message || "Login failed. Please try again.";

            loginMessage.style.color = "red";
            return;
        }

        // Save login information
        localStorage.setItem("estatehubToken", data.token);
        localStorage.setItem("estatehubUser", JSON.stringify(data.user));

        loginMessage.textContent = "Login successful! Redirecting...";
        loginMessage.style.color = "green";

        // Redirect according to user role
        const role = data.user.role.toLowerCase();

        let dashboardPage;

        if (role === "buyer") {
            dashboardPage = "buyer-dashboard.html";
        }
        else if (role === "owner") {
           dashboardPage = "owner-dashboard.html";
        }
        else if (role === "admin") {
            dashboardPage = "admin.html";
        }
        else {
            loginMessage.textContent = "Invalid user role.";
            loginMessage.style.color = "red";
            return;
        }

        setTimeout(() => {
            window.location.href = dashboardPage;
        }, 1000);

    } catch (error) {

        console.error("Login error:", error);

        loginMessage.textContent =
            "Unable to connect to the server. Please try again.";

        loginMessage.style.color = "red";
    }

});
