require("dotenv").config();

const express = require("express");
const path = require("path");
const cors = require("cors");
const db = require("./config/db");

const app = express();

app.use(cors());
app.use(express.json());
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

const authRoutes = require("./routes/authRoutes");
const propertyRoutes = require("./routes/propertyRoutes");
const adminRoutes = require("./routes/adminRoutes");
const enquiryRoutes = require("./routes/enquiryRoutes");
const verifyToken = require("./middleware/authMiddleware");

app.get("/", (req, res) => {
    res.send("Welcome to EstateHub API!");
});

// Authentication routes
app.use("/api/auth", authRoutes);
app.use("/api/properties", propertyRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/enquiries", enquiryRoutes);

// Protected profile route
app.get("/api/profile", verifyToken, (req, res) => {
    res.json({
        success: true,
        message: "You are logged in!",
        user: req.user
    });
});

// Database test
app.get("/api/test", (req, res) => {
    db.query("SELECT DATABASE() AS database_name", (err, result) => {
        if (err) {
            return res.status(500).json({
                success: false,
                message: err.message
            });
        }

        res.json({
            success: true,
            message: "EstateHub database is working!",
            database: result[0].database_name
        });
    });
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`EstateHub server running on http://localhost:${PORT}`);
});
