
const bcrypt = require("bcryptjs");
const readline = require("readline");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("Enter your new admin password: ", async (password) => {
    if (password.length < 6) {
        console.log("Password must contain at least 6 characters.");
        rl.close();
        return;
    }

    const hash = await bcrypt.hash(password, 10);

    console.log("\nPassword hash generated:");
    console.log(hash);

    rl.close();
});
