const db = require("../config/db");


// GET ALL APPROVED PROPERTIES WITH SEARCH, FILTER AND PAGINATION
exports.getAllProperties = (req, res) => {
   console.log("PAGINATION TEST - NEW CONTROLLER IS RUNNING");

    // Get search and filter values from URL query parameters
    const {
        city,
        listing_type,
        type_id,
        minPrice,
        maxPrice
    } = req.query;

    // Pagination
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit = Math.min(50, Math.max(1, parseInt(req.query.limit, 10) || 10));
    const offset = (page - 1) * limit;

    // Build dynamic SQL conditions
    let conditions = ["p.status = 'approved'"];
    let values = [];

    // Search by city name
    if (city) {
        conditions.push("c.city_name LIKE ?");
        values.push(`%${city}%`);
    }

    // Filter by sale or rent
    if (listing_type) {
        if (!["sale", "rent"].includes(listing_type)) {
            return res.status(400).json({
                success: false,
                message: "Listing type must be sale or rent"
            });
        }

        conditions.push("p.listing_type = ?");
        values.push(listing_type);
    }

    // Filter by property type
    if (type_id !== undefined) {
        if (!/^[1-9]\d*$/.test(type_id)) {
            return res.status(400).json({
                success: false,
                message: "Invalid property type ID"
            });
        }

        conditions.push("p.type_id = ?");
        values.push(Number(type_id));
    }

    // Filter by minimum price
    if (minPrice !== undefined) {
        if (minPrice.trim() === "" || !Number.isFinite(Number(minPrice)) || Number(minPrice) < 0) {
            return res.status(400).json({
                success: false,
                message: "Invalid minimum price"
            });
        }

        conditions.push("p.price >= ?");
        values.push(Number(minPrice));
    }

    // Filter by maximum price
    if (maxPrice !== undefined) {
        if (maxPrice.trim() === "" || !Number.isFinite(Number(maxPrice)) || Number(maxPrice) < 0) {
            return res.status(400).json({
                success: false,
                message: "Invalid maximum price"
            });
        }

        conditions.push("p.price <= ?");
        values.push(Number(maxPrice));
    }

    // Check minimum and maximum price
    if (minPrice !== undefined && maxPrice !== undefined &&
        Number(minPrice) > Number(maxPrice)) {
        return res.status(400).json({
            success: false,
            message: "Minimum price cannot exceed maximum price"
        });
    }

    const whereClause = conditions.join(" AND ");

    // Count matching properties
    const countSql = `
        SELECT COUNT(*) AS total
        FROM properties p
        JOIN cities c ON p.city_id = c.city_id
        WHERE ${whereClause}
    `;

    db.query(countSql, values, (err, countResult) => {

        if (err) {
            return res.status(500).json({
                success: false,
                message: err.message
            });
        }

        const total = countResult[0].total;

        // Fetch properties for the current page
        const sql = `
    SELECT p.*, c.city_name, pt.type_name,
           u.name AS owner_name,
           (
               SELECT pi.image_path
               FROM property_images pi
               WHERE pi.property_id = p.property_id
               ORDER BY pi.image_id DESC
               LIMIT 1
           ) AS image_path
    FROM properties p
    JOIN cities c ON p.city_id = c.city_id
    JOIN property_types pt ON p.type_id = pt.type_id
    JOIN users u ON p.owner_id = u.user_id
    WHERE ${whereClause}
    ORDER BY p.created_at DESC
    LIMIT ? OFFSET ?
`;
        db.query(sql, [...values, limit, offset], (err, result) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: err.message
                });
            }

            res.json({
                success: true,
                count: result.length,
                totalProperties: total,
                currentPage: page,
                totalPages: Math.ceil(total / limit),
                properties: result
            });
        });
    });
};


// GET PROPERTIES OF LOGGED-IN OWNER
exports.getMyProperties = (req, res) => {
    const sql = `
        SELECT * FROM properties
        WHERE owner_id = ?
        ORDER BY created_at DESC
    `;

    db.query(sql, [req.user.user_id], (err, result) => {
        if (err) {
            return res.status(500).json({
                success: false,
                message: err.message
            });
        }

        res.json({
            success: true,
            properties: result
        });
    });
};

// ADD NEW PROPERTY
exports.addProperty = (req, res) => {
    const {
        city_id,
        type_id,
        title,
        description,
        address,
        price,
        listing_type,
        bedrooms,
        bathrooms,
        area_sqft
    } = req.body;

    if (
        !city_id || !type_id || !title || !description ||
        !address || price === undefined || !listing_type
    ) {
        return res.status(400).json({
            success: false,
            message: "Please fill all required property details"
        });
    }

    if (!["sale", "rent"].includes(listing_type)) {
        return res.status(400).json({
            success: false,
            message: "Listing type must be sale or rent"
        });
    }

    if (Number(price) <= 0 || !Number.isFinite(Number(price))) {
        return res.status(400).json({
            success: false,
            message: "Price must be greater than zero"
        });
    }

    const sql = `
        INSERT INTO properties
        (owner_id, city_id, type_id, title, description, address,
         price, listing_type, bedrooms, bathrooms, area_sqft, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
    `;

    const values = [
        req.user.user_id,
        city_id,
        type_id,
        title,
        description,
        address,
        price,
        listing_type,
        bedrooms || 0,
        bathrooms || 0,
        area_sqft || 0
    ];

    db.query(sql, values, (err, result) => {
        if (err) {
            return res.status(500).json({
                success: false,
                message: err.message
            });
        }

        res.status(201).json({
            success: true,
            message: "Property submitted for admin approval!",
            propertyId: result.insertId
        });
    });
};

// UPDATE OWN PROPERTY
exports.updateProperty = (req, res) => {
    const { id } = req.params;

    const {
        city_id,
        type_id,
        title,
        description,
        address,
        price,
        listing_type,
        bedrooms,
        bathrooms,
        area_sqft
    } = req.body;

    if (
        !city_id || !type_id || !title || !description ||
        !address || price === undefined || !listing_type
    ) {
        return res.status(400).json({
            success: false,
            message: "Please provide all required property details"
        });
    }

    if (!["sale", "rent"].includes(listing_type) ||
        !Number.isFinite(Number(price)) || Number(price) <= 0) {
        return res.status(400).json({
            success: false,
            message: "Please provide a valid listing type and price"
        });
    }

    const sql = `
        UPDATE properties
        SET city_id = ?, type_id = ?, title = ?, description = ?,
            address = ?, price = ?, listing_type = ?, bedrooms = ?,
            bathrooms = ?, area_sqft = ?, status = 'pending'
        WHERE property_id = ? AND owner_id = ?
    `;

    const values = [
        city_id, type_id, title, description, address, price,
        listing_type, bedrooms || 0, bathrooms || 0, area_sqft || 0,
        id, req.user.user_id
    ];

    db.query(sql, values, (err, result) => {
        if (err) {
            return res.status(500).json({
                success: false,
                message: err.message
            });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: "Property not found or you do not own it"
            });
        }

        res.json({
            success: true,
            message: "Property updated and submitted for approval"
        });
    });
};

// DELETE OWN PROPERTY
exports.deleteProperty = (req, res) => {
    const { id } = req.params;

    const sql = `
        DELETE FROM properties
        WHERE property_id = ? AND owner_id = ?
    `;

    db.query(sql, [id, req.user.user_id], (err, result) => {
        if (err) {
            return res.status(500).json({
                success: false,
                message: err.message
            });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: "Property not found or you do not own it"
            });
        }

        res.json({
            success: true,
            message: "Property deleted successfully"
        });
    });
};

// UPLOAD PROPERTY IMAGES
exports.uploadPropertyImages = (req, res) => {
    const { id } = req.params;
    const userId = req.user.user_id;

    if (!req.files || req.files.length === 0) {
        return res.status(400).json({
            success: false,
            message: "Please upload at least one image"
        });
    }

    const checkSql = `
        SELECT property_id
        FROM properties
        WHERE property_id = ? AND owner_id = ?
    `;

    db.query(checkSql, [id, userId], (err, result) => {
        if (err) {
            return res.status(500).json({
                success: false,
                message: err.message
            });
        }

        if (result.length === 0) {
            return res.status(403).json({
                success: false,
                message: "Property not found or you are not the owner"
            });
        }

        const values = req.files.map(file => [
            id,
            "/uploads/" + file.filename
        ]);

        const insertSql = `
            INSERT INTO property_images (property_id, image_path)
            VALUES ?
        `;

        db.query(insertSql, [values], (err, insertResult) => {
            if (err) {
                return res.status(500).json({
                    success: false,
                    message: err.message
                });
            }

            res.status(201).json({
                success: true,
                message: "Property images uploaded successfully!",
                uploadedCount: insertResult.affectedRows,
                images: values.map(item => item[1])
            });
        });
    });
};
// GET SINGLE PROPERTY DETAILS BY ID
exports.getPropertyById = (req, res) => {
    const { id } = req.params;

    // Validate property ID
    if (!/^[1-9]\d*$/.test(id)) {
        return res.status(400).json({
            success: false,
            message: "Invalid property ID"
        });
    }

    const sql = `
        SELECT
            p.*,
            c.city_name,
            pt.type_name,
            u.name AS owner_name,
            (
                SELECT pi.image_path
                FROM property_images pi
                WHERE pi.property_id = p.property_id
                ORDER BY pi.image_id DESC
                LIMIT 1
            ) AS image_path
        FROM properties p
        JOIN cities c ON p.city_id = c.city_id
        JOIN property_types pt ON p.type_id = pt.type_id
        JOIN users u ON p.owner_id = u.user_id
        WHERE p.property_id = ?
        AND p.status = 'approved'
    `;

    db.query(sql, [id], (err, result) => {
        if (err) {
            return res.status(500).json({
                success: false,
                message: err.message
            });
        }

        if (result.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Property not found"
            });
        }

        res.json({
            success: true,
            property: result[0]
        });
    });
};

