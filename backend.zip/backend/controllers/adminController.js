
const db = require("../config/db");

// VIEW ALL PENDING PROPERTIES
exports.getPendingProperties = (req, res) => {
    const sql = `
        SELECT p.*, c.city_name, pt.type_name, u.name AS owner_name
        FROM properties p
        JOIN cities c ON p.city_id = c.city_id
        JOIN property_types pt ON p.type_id = pt.type_id
        JOIN users u ON p.owner_id = u.user_id
        WHERE p.status = 'pending'
        ORDER BY p.created_at DESC
    `;

    db.query(sql, (err, result) => {
        if (err) {
            return res.status(500).json({
                success: false,
                message: err.message
            });
        }

        res.json({
            success: true,
            count: result.length,
            properties: result
        });
    });
};

// APPROVE OR REJECT PROPERTY
exports.updatePropertyStatus = (req, res) => {
    const { id } = req.params;
    const { status } = req.body;

    if (!["approved", "rejected"].includes(status)) {
        return res.status(400).json({
            success: false,
            message: "Status must be approved or rejected"
        });
    }

    const sql = `
        UPDATE properties
        SET status = ?
        WHERE property_id = ? AND status = 'pending'
    `;

    db.query(sql, [status, id], (err, result) => {
        if (err) {
            return res.status(500).json({
                success: false,
                message: err.message
            });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: "Pending property not found"
            });
        }

        res.json({
            success: true,
            message: `Property ${status} successfully!`
        });
    });
};
