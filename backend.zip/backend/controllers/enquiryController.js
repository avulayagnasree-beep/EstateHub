
const db = require("../config/db");

// CREATE ENQUIRY
exports.createEnquiry = (req, res) => {
    const { property_id, message } = req.body;
    const buyer_id = req.user.user_id;

    if (!property_id || !message || !message.trim()) {
        return res.status(400).json({
            success: false,
            message: "Property ID and message are required."
        });
    }

    const sql = `
        INSERT INTO enquiries (property_id, buyer_id, message, status)
        SELECT p.property_id, ?, ?, 'new'
        FROM properties p
        WHERE p.property_id = ?
        AND p.status = 'approved'
        AND p.owner_id != ?
    `;

    db.query(
        sql,
        [buyer_id, message.trim(), property_id, buyer_id],
        (err, result) => {
            if (err) {
                return res.status(500).json({
                    success: false,
                    message: err.message
                });
            }

            if (result.affectedRows === 0) {
                return res.status(404).json({
                    success: false,
                    message: "Property not found or you cannot enquire about your own property."
                });
            }

            res.status(201).json({
                success: true,
                message: "Your enquiry has been sent successfully!",
                enquiry_id: result.insertId
            });
        }
    );
};

// VIEW ENQUIRIES RECEIVED BY OWNER
exports.getOwnerEnquiries = (req, res) => {
    const owner_id = req.user.user_id;

    const sql = `
        SELECT
            e.*,
            p.title AS property_title,
            u.name AS buyer_name
        FROM enquiries e
        JOIN properties p ON e.property_id = p.property_id
        JOIN users u ON e.buyer_id = u.user_id
        WHERE p.owner_id = ?
        ORDER BY e.created_at DESC
    `;

    db.query(sql, [owner_id], (err, result) => {
        if (err) {
            return res.status(500).json({
                success: false,
                message: err.message
            });
        }

        res.json({
            success: true,
            count: result.length,
            enquiries: result
        });
    });
};

// VIEW ENQUIRIES SENT BY BUYER
exports.getMyEnquiries = (req, res) => {
    const buyer_id = req.user.user_id;

    const sql = `
        SELECT
            e.*,
            p.title AS property_title,
            p.address,
            c.city_name
        FROM enquiries e
        JOIN properties p ON e.property_id = p.property_id
        JOIN cities c ON p.city_id = c.city_id
        WHERE e.buyer_id = ?
        ORDER BY e.created_at DESC
    `;

    db.query(sql, [buyer_id], (err, result) => {
        if (err) {
            return res.status(500).json({
                success: false,
                message: err.message
            });
        }

        res.json({
            success: true,
            count: result.length,
            enquiries: result
        });
    });
};
