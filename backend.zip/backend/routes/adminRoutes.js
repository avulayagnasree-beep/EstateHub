
const express = require("express");
const router = express.Router();

const adminController = require("../controllers/adminController");
const verifyToken = require("../middleware/authMiddleware");
const adminMiddleware = require("../middleware/adminMiddleware");

// All admin routes require login and admin role
router.use(verifyToken, adminMiddleware);

// View pending properties
router.get("/pending-properties", adminController.getPendingProperties);

// Approve or reject property
router.put("/properties/:id/status", adminController.updatePropertyStatus);

// Export router
module.exports = router;
