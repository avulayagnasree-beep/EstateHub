
const express = require("express");
const router = express.Router();

const enquiryController = require("../controllers/enquiryController");
const verifyToken = require("../middleware/authMiddleware");

// Send an enquiry
router.post("/", verifyToken, enquiryController.createEnquiry);

// View enquiries received by the logged-in owner
router.get("/owner", verifyToken, enquiryController.getOwnerEnquiries);

// View enquiries sent by the logged-in buyer
router.get("/my-enquiries", verifyToken, enquiryController.getMyEnquiries);

module.exports = router;
