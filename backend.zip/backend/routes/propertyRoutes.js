
const express = require("express");
const router = express.Router();

const propertyController = require("../controllers/propertyController");
const verifyToken = require("../middleware/authMiddleware");
const upload = require("../middleware/uploadMiddleware");

// Public route: View all approved properties
router.get("/", propertyController.getAllProperties);

// Protected route: View owner's properties
router.get("/my-properties", verifyToken, propertyController.getMyProperties);

// Public route: View one property's details
router.get("/:id", propertyController.getPropertyById);

// Protected route: Add a property
router.post("/", verifyToken, propertyController.addProperty);

// Protected route: Upload property images
router.post(
    "/:id/images",
    verifyToken,
    upload.array("images", 5),
    propertyController.uploadPropertyImages
);

// Protected route: Update a property
router.put("/:id", verifyToken, propertyController.updateProperty);

// Protected route: Delete a property
router.delete("/:id", verifyToken, propertyController.deleteProperty);

module.exports = router;